//
// Created by Xufeng Zhan on 2023/9/13.
//
#include <bits/stdc++.h>
using namespace std;

struct Point{
    double x, y, z;
    explicit Point(double x = 0, double y = 0, double z = 0):x(x), y(y), z(z){}
    Point operator - (const Point& other) const {
        return Point(x - other.x, y - other.y, z - other.z);
    }
    friend ostream& operator << (ostream& str, Point& pt){
        cout << pt.x << " " << pt.y << " " << pt.z;
        return cout;
    }
};

const Point A = Point(1, 0, 0),
        B = Point(-1, 0, 0),
        C = Point(0, sqrt(3), 0);


double get_dist(Point a, Point b){
    Point diff = b - a;
    return sqrt(diff.x * diff.x + diff.y * diff.y + diff.z * diff.z);
}

double get_angle(double a, double b, double c){
    // get angle A from triangle ABC
    return acos((b * b + c * c - a * a) / 2 / b / c);
}

void create_angles(Point D){

    double distAB = get_dist(A, B),
            distBC = get_dist(B, C),
            distAC = get_dist(A, C);
    double distAD = get_dist(A, D),
            distBD = get_dist(B, D),
            distCD = get_dist(C, D);
    double angleADB = get_angle(distAB, distAD, distBD),
            angleADC = get_angle(distAC, distAD, distCD),
            angleBDC = get_angle(distBC, distBD, distCD);

    cout << angleADB << " " << angleADC << " " << angleBDC << endl;
}

int main(){
    Point pt;
    cin >> pt.x >> pt.y >> pt.z;
    create_angles(pt);


    return 0;
}