#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;

struct Point{
    double x, y, z;
    explicit Point(double x = 0, double y = 0, double z = 0):x(x), y(y), z(z){}
    Point operator - (const Point& other) const {
        return Point(x - other.x, y - other.y, z - other.z);
    }
    friend ostream& operator << (ostream& str, Point& pt){
        cout << pt.x << " " << pt.y << " " << pt.z;
        return cout;
    }
};

const Point A = Point(1, 0, 0),
            B = Point(-1, 0, 0),
            C = Point(0, sqrt(3), 0);

const double RANGE_MAX = 1000;
const int ROUND_MAX = 1000;
const double EPSILON = 1e-3;

double givenADB, givenADC, givenBDC;

double get_dist(Point a, Point b){
    Point diff = b - a;
    return sqrt(diff.x * diff.x + diff.y * diff.y + diff.z * diff.z);
}

double get_angle(double a, double b, double c){
    // get angle A from triangle ABC
    return acos((b * b + c * c - a * a) / 2 / b / c);
}

double min_f = 1000000; Point answer;

vector <Point> solutionSet;
//double penalty_func(Point D){
//    double result = 0;
//    for (auto &x : X){
//        result -= get_dist(Point(0, 0), D - x);
//    }
//    return result;
//}

double valuation_func(Point D){
    double distAB = get_dist(A, B),
           distBC = get_dist(B, C),
           distAC = get_dist(A, C);
    double distAD = get_dist(A, D),
           distBD = get_dist(B, D),
           distCD = get_dist(C, D);
    double angleADB = get_angle(distAB, distAD, distBD),
           angleADC = get_angle(distAC, distAD, distCD),
           angleBDC = get_angle(distBC, distBD, distCD);

//    without penalty function
    double f = fabs(angleADB - givenADB) + fabs(angleADC - givenADC) + fabs(angleBDC - givenBDC);

    if (f < min_f){
        min_f = f;
        answer.x = D.x; answer.y = D.y; answer.z = D.z;
    }
    return f;
}

double Rand(){ return (double)rand() / RAND_MAX; }
double my_rand(){ return Rand() * 2 - 1; }

void simulate_anneal(){
    double t = RANGE_MAX;
    Point cur_pt = Point(50, 50, -50);
    int iter_cnt = 0;
    while (t > 0.0001){
        Point nxt_pt = Point(cur_pt.x + t * my_rand(), cur_pt.y + t * my_rand(), 1);
        while (nxt_pt.z >= 0) nxt_pt.z = cur_pt.z + t * my_rand();
        iter_cnt ++;
//        cout << "iteration: " << iter_cnt << endl;
//        cout << "current point: " << cur_pt << endl;
//        cout << "valuation function: " << valuation_func(cur_pt) << endl << endl;
        double delta = valuation_func(nxt_pt) - valuation_func(cur_pt);
        if (delta < 0) cur_pt = nxt_pt;
//        if (exp(- delta / t) > Rand()) cur_pt = nxt_pt;
        t *= 0.97;
    }
    for (int i = 0; i < 1000; ++ i){
        Point nxt_pt = Point(cur_pt.x + t * my_rand(), cur_pt.y + t * my_rand(), 1);
        while (nxt_pt.z >= 0) nxt_pt.z = cur_pt.z + t * my_rand();
        valuation_func(nxt_pt);
    }
}

bool cmp(Point a, Point b){
    return valuation_func(a) < valuation_func(b);
}

int main() {
    srand(time(nullptr));
    cin >> givenADB >> givenADC >> givenBDC;
//    cout << valuation_func(Point(0, sqrt(3) / 3, 0));
    for (int N = 0; N < ROUND_MAX; ++ N){
        min_f = 1000000;
        simulate_anneal();
        solutionSet.emplace_back(answer);
    }
    sort(solutionSet.begin(), solutionSet.end(), cmp);
    cout << "solutions:" << endl;
    for (int i = 0; i < solutionSet.size(); ++ i){
        bool newSolution = true;
        for (int j = 0; j < solutionSet.size(); ++ j){
            if (j == i) continue;
            if (get_dist(solutionSet[i], solutionSet[j]) < EPSILON) newSolution = false;
        }
        if (newSolution) cout << solutionSet[i] << endl;
    }
    cout << "finish." << endl;
    return 0;
}
